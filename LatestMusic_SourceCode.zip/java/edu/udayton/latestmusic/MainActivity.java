package edu.udayton.latestmusic;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnMusic = (Button) findViewById(R.id.btnMusic);

        //Event handler for Button btnMusic

        View.OnClickListener btnMusiclistener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent for the Music Screen

                Intent musicIntent = new Intent(MainActivity.this, Music.class);

                //Starting new Music Activity with musicIntent

                startActivity(musicIntent);

            }
        };


        // Setting btnMusicListener as btnMusic's event handler

        btnMusic.setOnClickListener(btnMusiclistener);
    }
}
