package edu.udayton.personalplaylist;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnColdplay, btnLinkin, btnImagine;

    private MediaPlayer mpColdplay, mpLinkin, mpImagine;
    private int playing;

    private static final int NOT_PLAYING = 0, PLAYING = 1;
    private static final String COLDPLAY_PLAYING = "Pause Coldplay Song",
                                COLDPLAY_PAUSED = "Play Coldplay Song",
                                LINKIN_PLAYING = "Pause Linkin Park Song",
                                LINKIN_PAUSED = "Play Linkin Park Song",
                                IMAGINE_PLAYING ="Pause Imagine Dragons Song",
                                IMAGINE_PAUSED = "Play Imagine Dragons Song";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnColdplay = (Button) findViewById(R.id.btnColdplay);
        btnImagine = (Button) findViewById(R.id.btnImagine);
        btnLinkin = (Button) findViewById(R.id.btnLinkin);

        btnLinkin.setOnClickListener(btnLinkinListener);
        btnColdplay.setOnClickListener(btnColdplayListener);
        btnImagine.setOnClickListener(btnImagineListener);

        mpColdplay = new MediaPlayer();
        mpColdplay = MediaPlayer.create(this, R.raw.coldplay);

        mpImagine = new MediaPlayer();
        mpImagine = MediaPlayer.create(this, R.raw.imagine);

        mpLinkin = new MediaPlayer();
        mpLinkin = MediaPlayer.create(this, R.raw.linkin);

        playing = NOT_PLAYING;
    }

    Button.OnClickListener btnColdplayListener = new Button.OnClickListener()
    {

        @Override
        public void onClick(View v) {

            switch (playing)
            {
                case NOT_PLAYING:
                    mpColdplay.start();
                    playing = PLAYING;

                    btnColdplay.setText(COLDPLAY_PLAYING);
                    btnImagine.setVisibility(View.INVISIBLE);
                    btnLinkin.setVisibility(View.INVISIBLE);
                    break;

                case PLAYING:
                    mpColdplay.pause();
                    playing = NOT_PLAYING;
                    btnColdplay.setText(COLDPLAY_PAUSED);
                    btnImagine.setVisibility(View.VISIBLE);
                    btnLinkin.setVisibility(View.VISIBLE);
                    break;

            }

        }
    };

    Button.OnClickListener btnLinkinListener = new Button.OnClickListener()
    {

        @Override
        public void onClick(View v) {

            switch (playing)
            {
                case NOT_PLAYING:
                    mpLinkin.start();
                    playing = PLAYING;
                    btnLinkin.setText(LINKIN_PLAYING);
                    btnColdplay.setVisibility(View.INVISIBLE);
                    btnImagine.setVisibility(View.INVISIBLE);
                    break;

                case PLAYING:
                    mpLinkin.pause();
                    playing = NOT_PLAYING;
                    btnLinkin.setText(LINKIN_PAUSED);
                    btnColdplay.setVisibility(View.VISIBLE);
                    btnImagine.setVisibility(View.VISIBLE);
                    break;


            }

        }
    };

    Button.OnClickListener btnImagineListener = new Button.OnClickListener()
    {

        @Override
        public void onClick(View v) {

            switch (playing)
            {
                case NOT_PLAYING:
                    mpImagine.start();
                    playing = PLAYING;
                    btnImagine.setText(IMAGINE_PLAYING);
                    btnLinkin.setVisibility(View.INVISIBLE);
                    btnColdplay.setVisibility(View.INVISIBLE);
                    break;

                case PLAYING:
                    mpImagine.pause();
                    playing = NOT_PLAYING;
                    btnImagine.setText(IMAGINE_PAUSED);
                    btnLinkin.setVisibility(View.VISIBLE);
                    btnColdplay.setVisibility(View.VISIBLE);
                    break;
            }

        }
    };
}
