package edu.udayton.splitthebill;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private double BILL_AMOUNT,BILL_SPLIT;
    private int numberOfPeople;
    private String qualityOfService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Total Bill Button reference

        final Button btnTotalCost = (Button) findViewById(R.id.btnTotalCost);

        //validating the btnTotalCost

        assert btnTotalCost!=null;

        View.OnClickListener btnTotalCostListener = new View.OnClickListener() {


            final EditText txtBill = (EditText) findViewById(R.id.txtBill);
            final EditText txtPeople = (EditText) findViewById(R.id.txtPeople);
            final Spinner txtGroup = (Spinner) findViewById(R.id.txtGroup);
            final TextView txtResult = (TextView) findViewById(R.id.txtResult);
            final TextView txtComment = (TextView) findViewById(R.id.txtComment);

            @Override
            public void onClick(View v) {

                Editable InputBill = txtBill.getText();
                String InputStringBill = InputBill.toString();

                Editable InputPeople = txtPeople.getText();
                String InputStringPeople = InputPeople.toString();


                try
                {

                    BILL_AMOUNT = Integer.parseInt(InputStringBill);
                    numberOfPeople = Integer.parseInt(InputStringPeople);

                    qualityOfService = txtGroup.getSelectedItem().toString();

                    switch (qualityOfService)
                    {
                        case "Excellent":
                            BILL_SPLIT = (BILL_AMOUNT* 1.20) / numberOfPeople;
                            DecimalFormat currencyExcellent = new DecimalFormat("$###,###.##");
                            txtResult.setText("Total Bill Split for each person is "+currencyExcellent.format(BILL_SPLIT));
                            txtComment.setText("One of the best meals ever!  I will recommend this place to everyone I know!");
                            break;

                        case "Average":
                            BILL_SPLIT = (BILL_AMOUNT *1.15)/numberOfPeople;
                            DecimalFormat currencyAverage = new DecimalFormat("$###,###.##");
                            txtResult.setText("Total Bill Split for each person is "+currencyAverage.format(BILL_SPLIT));
                            txtComment.setText("Everything was OK.");
                            break;

                        case "Poor":
                            BILL_SPLIT = (BILL_AMOUNT*1.05)/numberOfPeople;
                            DecimalFormat currencyPoor = new DecimalFormat("$###,###.##");
                            txtResult.setText("Total Bill Split for each person is "+currencyPoor.format(BILL_SPLIT));
                            txtComment.setText("Awful!  The worst!  I can't wait to give negative reviews on Yelp!");
                            break;
                    }

                }catch (Exception ex)
                {
                    Log.e(ex.getMessage(), ex.toString());
                }

            }
        };


        btnTotalCost.setOnClickListener(btnTotalCostListener);

    }
}
