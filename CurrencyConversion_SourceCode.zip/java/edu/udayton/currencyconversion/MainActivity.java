package edu.udayton.currencyconversion;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends Activity {

    private final double USD_TO_EUR = 0.883304;
    private final double USD_TO_MXN = 19.1354;
    private final double USD_TO_CAD = 1.32932;

    private double currencyUSD, convertedCurrency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final Button btnConvert = (Button) findViewById(R.id.btnConvert);

        View.OnClickListener btnConvertListener = new View.OnClickListener() {


            final EditText txtCurrency = (EditText) findViewById(R.id.txtCurrency);
            final RadioButton radUSDToEUR = (RadioButton) findViewById(R.id.radUSDToEUR);
            final RadioButton radUSDToMXN = (RadioButton) findViewById(R.id.radUSDToMXN);
            final RadioButton radUSDToCAD = (RadioButton) findViewById(R.id.radUSDToCAD);

            final TextView txtResult= (TextView) findViewById(R.id.txtResult);
            final DecimalFormat decimalFormat = new DecimalFormat("###.####");

            @Override
            public void onClick(View v) {

                String inputString = txtCurrency.getText().toString();

                String outputString = "Invalid Currency.";

                try
                {
                    currencyUSD = Double.parseDouble(inputString);


                    if(currencyUSD>0 && currencyUSD<100000)
                    {
                        if(radUSDToEUR.isChecked())
                        {
                            convertedCurrency = USD_TO_EUR*(currencyUSD);

                            outputString = decimalFormat.format(convertedCurrency) + " EUR";
                        }
                        else if(radUSDToCAD.isChecked())
                        {
                            convertedCurrency = USD_TO_CAD*(currencyUSD);

                            outputString = decimalFormat.format(convertedCurrency) + " CAD";
                        }
                        else if(radUSDToMXN.isChecked())
                        {
                            convertedCurrency = USD_TO_MXN*(currencyUSD);

                            outputString = decimalFormat.format(convertedCurrency) + " MXN";
                        }
                    }


                }catch (Exception ex)
                {
                    Toast myToast = Toast.makeText(MainActivity.this, ex.toString(), Toast.LENGTH_LONG);
                    myToast.show();
                }

                txtResult.setText(outputString);

            }
        };

        btnConvert.setOnClickListener(btnConvertListener);
    }
}
