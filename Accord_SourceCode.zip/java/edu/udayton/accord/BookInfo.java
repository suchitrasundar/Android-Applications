package edu.udayton.accord;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class BookInfo extends AppCompatActivity {

    public static final String ID_KEY = "RES_ID",
            LBL_KEY ="LABEL", DES_KEY ="DESCRIPTION";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_info);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        Bundle ext = intent.getExtras();

        if(extras != null && ext!=null) {
            final String res_label = extras.getString(LBL_KEY);
            final String des_label = ext.getString(DES_KEY);

            final TextView titleTextViewS4  = (TextView) findViewById(R.id.titleTextViewS4);
            titleTextViewS4.setText(res_label);

            final TextView bookTextView = (TextView) findViewById(R.id.bookTextView);
            bookTextView.setText(des_label);

            String image_id = extras.getString(ID_KEY);


            int imageId = Integer.parseInt(image_id);


            final ImageView bookImageView = (ImageView) findViewById(R.id.bookImageView);
            bookImageView.setImageResource(imageId);
            bookImageView.setContentDescription(res_label);
            bookImageView.setContentDescription(des_label);

            Button button = (Button) findViewById(R.id.btnLinkBook);
            View.OnClickListener listener = new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent in = null;

                    if (res_label.equals(getString(R.string.txtB1)) && des_label.equals(R.string.txtDesB1)) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.kidsneedtoread.org/"));
                    } else if (res_label.equals(getString(R.string.txtB2)) && des_label.equals(R.string.txtDesB2)) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.betterworldbooks.com/"));
                    } else if (res_label.equals(getString(R.string.txtB3)) && des_label.equals(R.string.txtDesB3)) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.readertoreader.org/"));
                    } else if (res_label.equals(getString(R.string.txtB4)) && des_label.equals(R.string.txtDesB4)) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.freecycle.org/"));
                    } else if (res_label.equals(getString(R.string.txtB5)) && des_label.equals(R.string.txtDesB5)) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("http://bookmooch.com/"));
                    }
                    startActivity(in);


                }
            };

            button.setOnClickListener(listener);

        }

    }
}
