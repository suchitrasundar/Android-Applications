package edu.udayton.accord;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class Food extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_food);

        List<String> Food = Arrays.asList(getResources().getStringArray(R.array.FoodList));
        setListAdapter(new ArrayAdapter<String>(this,R.layout.activity_food, R.id.food, Food));

    }

    protected void onListItemClick(ListView l, View v, int position, long id)
    {
        Intent intent;
        switch (position)
        {
            case 0:
                intent = new Intent(Food.this, FoodInfo.class);
                intent.putExtra(FoodInfo.LBL_KEY,getResources().getString(R.string.txtF1));
                intent.putExtra(FoodInfo.ID_KEY,Integer.toString(R.drawable.feeding_america));
                intent.putExtra(FoodInfo.DES_KEY, getResources().getString(R.string.txtDesF1));
                break;
            case 1:
                intent = new Intent(Food.this, FoodInfo.class);
                intent.putExtra(FoodInfo.LBL_KEY,getResources().getString(R.string.txtF2));
                intent.putExtra(FoodInfo.ID_KEY,Integer.toString(R.drawable.feed_the_children));
                intent.putExtra(FoodInfo.DES_KEY, getResources().getString(R.string.txtDesF2));
                break;
            case 2:
                intent = new Intent(Food.this, FoodInfo.class);
                intent.putExtra(FoodInfo.LBL_KEY,getResources().getString(R.string.txtF3));
                intent.putExtra(FoodInfo.ID_KEY,Integer.toString(R.drawable.no_kid_hungry));
                intent.putExtra(FoodInfo.DES_KEY, getResources().getString(R.string.txtDesF3));
                break;
            case 3:
                intent = new Intent(Food.this, FoodInfo.class);
                intent.putExtra(FoodInfo.LBL_KEY,getResources().getString(R.string.txtF4));
                intent.putExtra(FoodInfo.ID_KEY,Integer.toString(R.drawable.food_for_the_hungry));
                intent.putExtra(FoodInfo.DES_KEY, getResources().getString(R.string.txtDesF4));
                break;
            case 4:
                intent = new Intent(Food.this, FoodInfo.class);
                intent.putExtra(FoodInfo.LBL_KEY,getResources().getString(R.string.txtF5));
                intent.putExtra(FoodInfo.ID_KEY,Integer.toString(R.drawable.food_for_the_poor));
                intent.putExtra(FoodInfo.DES_KEY, getResources().getString(R.string.txtDesF5));
                break;
            default:
                Toast toast = Toast.makeText(Food.this,"Invalid Choice Made", Toast.LENGTH_LONG);
                toast.show();
                intent = null;
        }
        if(intent != null)
        {
            startActivity(intent);
        }

    }

}
