package edu.udayton.accord;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class Books extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_books);

        List<String> Books = Arrays.asList(getResources().getStringArray(R.array.BookList));
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_books, R.id.books, Books));
    }

    protected void onListItemClick(ListView l, View v, int position, long id)
    {
        Intent intent;
        switch (position)
        {
            case 0:
                intent = new Intent(Books.this, BookInfo.class);
                intent.putExtra(BookInfo.LBL_KEY,getResources().getString(R.string.txtB1));
                intent.putExtra(BookInfo.ID_KEY,Integer.toString(R.drawable.kids_need_to_read));
                intent.putExtra(BookInfo.DES_KEY,getResources().getString(R.string.txtDesB1));
                break;
            case 1:
                intent = new Intent(Books.this, BookInfo.class);
                intent.putExtra(BookInfo.LBL_KEY,getResources().getString(R.string.txtB2));
                intent.putExtra(BookInfo.ID_KEY,Integer.toString(R.drawable.better_world_books));
                intent.putExtra(BookInfo.DES_KEY, getResources().getString(R.string.txtDesB2));
                break;
            case 2:
                intent = new Intent(Books.this, BookInfo.class);
                intent.putExtra(BookInfo.LBL_KEY,getResources().getString(R.string.txtB3));
                intent.putExtra(BookInfo.ID_KEY,Integer.toString(R.drawable.reader_to_reader));
                intent.putExtra(BookInfo.DES_KEY, getResources().getString(R.string.txtDesB3));
                break;
            case 3:
                intent = new Intent(Books.this, BookInfo.class);
                intent.putExtra(BookInfo.LBL_KEY,getResources().getString(R.string.txtB4));
                intent.putExtra(BookInfo.ID_KEY,Integer.toString(R.drawable.freecycle));
                intent.putExtra(BookInfo.DES_KEY, getResources().getString(R.string.txtDesB4));
                break;
            case 4:
                intent = new Intent(Books.this, BookInfo.class);
                intent.putExtra(BookInfo.LBL_KEY,getResources().getString(R.string.txtB5));
                intent.putExtra(BookInfo.ID_KEY,Integer.toString(R.drawable.bookmooch));
                intent.putExtra(BookInfo.DES_KEY,getResources().getString(R.string.txtDesB5));
                break;
            default:
                Toast toast = Toast.makeText(Books.this,"Invalid Choice Made", Toast.LENGTH_LONG);
                toast.show();
                intent = null;
        }
        if(intent != null)
        {
            startActivity(intent);
        }

    }

}
