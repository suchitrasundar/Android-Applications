package edu.udayton.accord;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnS1 = (Button) findViewById(R.id.btnS1);

        View.OnClickListener btnS1Listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent choiceIntent = new Intent(MainActivity.this, Choice.class);
                startActivity(choiceIntent);
            }
        };

        btnS1.setOnClickListener(btnS1Listener);
    }
}
