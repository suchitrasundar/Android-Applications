package edu.udayton.accord;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class Choice extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);

        final Button btnS2 = (Button) findViewById(R.id.btnS2);

        View.OnClickListener btnS2Listener = new View.OnClickListener() {

            final RadioButton radioButtonFood = (RadioButton) findViewById(R.id.radioButtonFood);
            final RadioButton radioButtonClothes = (RadioButton) findViewById(R.id.radioButtonClothes);
            final RadioButton radioButtonBooks = (RadioButton) findViewById(R.id.radioButtonBooks);

            @Override
            public void onClick(View v) {

                try
                {
                    if(radioButtonFood.isChecked())
                    {
                        Intent intentFood = new Intent(Choice.this, Food.class);
                        startActivity(intentFood);
                    }
                    else if(radioButtonBooks.isChecked())
                    {
                        Intent intentBooks = new Intent(Choice.this, Books.class);
                        startActivity(intentBooks);
                    }
                    else if(radioButtonClothes.isChecked())
                    {
                        Intent intentClothes = new Intent(Choice.this, Clothes.class);
                        startActivity(intentClothes);
                    }
                }
                catch (Exception ex)
                {
                    Toast myToast = Toast.makeText(Choice.this, ex.toString(), Toast.LENGTH_LONG);
                    myToast.show();
                }

            }
        };

        btnS2.setOnClickListener(btnS2Listener);
    }
}
