package edu.udayton.accord;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class Clothes extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_clothes);

        List<String> Clothes = Arrays.asList(getResources().getStringArray(R.array.ClothesList));
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_clothes, R.id.clothes, Clothes));

    }

    protected void onListItemClick(ListView l, View v, int position, long id)
    {
        Intent intent;
        switch (position)
        {
            case 0:
                intent = new Intent(Clothes.this, ClothesInfo.class);
                intent.putExtra(ClothesInfo.LBL_KEY,getResources().getString(R.string.txtC1));
                intent.putExtra(ClothesInfo.ID_KEY,Integer.toString(R.drawable.goodwill));
                intent.putExtra(ClothesInfo.DES_KEY, getResources().getString(R.string.txtDesC1));
                break;
            case 1:
                intent = new Intent(Clothes.this, ClothesInfo.class);
                intent.putExtra(ClothesInfo.LBL_KEY,getResources().getString(R.string.txtC2));
                intent.putExtra(ClothesInfo.ID_KEY,Integer.toString(R.drawable.the_salvation_army));
                intent.putExtra(ClothesInfo.DES_KEY, getResources().getString(R.string.txtDesC2));
                break;
            case 2:
                intent = new Intent(Clothes.this, ClothesInfo.class);
                intent.putExtra(ClothesInfo.LBL_KEY,getResources().getString(R.string.txtC3));
                intent.putExtra(ClothesInfo.ID_KEY,Integer.toString(R.drawable.purple_heart_foundation));
                intent.putExtra(ClothesInfo.DES_KEY,getResources().getString(R.string.txtDesC3));
                break;
            case 3:
                intent = new Intent(Clothes.this, ClothesInfo.class);
                intent.putExtra(ClothesInfo.LBL_KEY,getResources().getString(R.string.txtC4));
                intent.putExtra(ClothesInfo.ID_KEY,Integer.toString(R.drawable.amvets));
                intent.putExtra(ClothesInfo.DES_KEY,getResources().getString(R.string.txtDesC4));
                break;
            case 4:
                intent = new Intent(Clothes.this, ClothesInfo.class);
                intent.putExtra(ClothesInfo.LBL_KEY,getResources().getString(R.string.txtC5));
                intent.putExtra(ClothesInfo.ID_KEY,Integer.toString(R.drawable.big_brother_big_sister));
                intent.putExtra(ClothesInfo.DES_KEY,getResources().getString(R.string.txtDesC5));
                break;
            default:
                Toast toast = Toast.makeText(Clothes.this,"Invalid Choice Made", Toast.LENGTH_LONG);
                toast.show();
                intent = null;
        }
        if(intent != null)
        {
            startActivity(intent);
        }

    }

}
