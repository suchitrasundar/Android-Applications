package edu.udayton.accord;

import android.app.ListActivity;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Arrays;
import java.util.List;

public class ClothesInfo extends AppCompatActivity {

    public static final String ID_KEY = "RES_ID",
            LBL_KEY ="LABEL", DES_KEY ="DESCRIPTION";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_clothes_info);

        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        Bundle ext = intent.getExtras();

        if(extras != null && ext!=null) {
            final String res_label = extras.getString(LBL_KEY);
            final String des_label = ext.getString(DES_KEY);


            final TextView titleTextViewS5 = (TextView) findViewById(R.id.titleTextViewS5);
            titleTextViewS5.setText(res_label);

            final TextView clothesTextView = (TextView) findViewById(R.id.clothesTextView);
            clothesTextView.setText(des_label);

            String image_id = extras.getString(ID_KEY);


            int imageId = Integer.parseInt(image_id);


            final ImageView clothesImageView = (ImageView) findViewById(R.id.clothesImageView);
            clothesImageView.setImageResource(imageId);
            clothesImageView.setContentDescription(res_label);
            clothesImageView.setContentDescription(des_label);

            Button button = (Button) findViewById(R.id.btnLinkClothes);
            View.OnClickListener listener = new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent in = null;

                    if (res_label.equals(getString(R.string.txtC1)) && des_label.equals(getString(R.string.txtDesC1))) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.goodwill.org/donate/"));
                    } else if (res_label.equals(getString(R.string.txtC2)) && des_label.equals(getString(R.string.txtDesC2))) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.salvationarmyusa.org/usn/"));
                    } else if (res_label.equals(getString(R.string.txtC3))&& des_label.equals(getString(R.string.txtDesC3))) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://purpleheartfoundation.org/"));
                    } else if (res_label.equals(getString(R.string.txtC4)) && des_label.equals(getString(R.string.txtDesC4))) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://amvets.org/"));
                    } else if (res_label.equals(getString(R.string.txtC5)) && des_label.equals(getString(R.string.txtDesC5))) {
                        in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.bbbs.org/"));
                    }
                    startActivity(in);


                }
            };

            button.setOnClickListener(listener);

        }

    }



    }

