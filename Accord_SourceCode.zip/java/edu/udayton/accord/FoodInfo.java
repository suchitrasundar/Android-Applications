package edu.udayton.accord;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class FoodInfo extends AppCompatActivity {

    public static final String ID_KEY = "RES_ID",
    LBL_KEY ="LABEL", DES_KEY ="DESCRIPTION";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_info);

        Intent myIntent = getIntent();
        Bundle myExtras = myIntent.getExtras();
        Bundle ext = myIntent.getExtras();

        if(myExtras!=null && ext!=null)
        {
            final String res_label = myExtras.getString(LBL_KEY);
            final String des_label =  ext.getString(DES_KEY);

            final TextView titleTextViewS3 = (TextView) findViewById(R.id.titleTextViewS3);
            titleTextViewS3.setText(res_label);

            final TextView foodTextView = (TextView) findViewById(R.id.foodTextView);
            foodTextView.setText(des_label);


            String image_id = myExtras.getString(ID_KEY);
            int imageID = Integer.parseInt(image_id);

            final ImageView foodImageView = (ImageView) findViewById(R.id.foodImageView);
            foodImageView.setImageResource(imageID);
            foodImageView.setContentDescription(res_label);
            foodImageView.setContentDescription(des_label);

            Button btnLink = (Button) findViewById(R.id.btnLink);
            View.OnClickListener btnLinkListener = new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent itemIntent = null;

                    if(res_label.equals(getString(R.string.txtF1)) && des_label.equals(getString(R.string.txtDesF1)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.feedingamerica.org/"));

                    }
                    else if(res_label.equals(getString(R.string.txtF2)) && des_label.equals(getString(R.string.txtDesF2)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.feedthechildren.org/"));
                    }
                    else if(res_label.equals(getString(R.string.txtF3)) && des_label.equals(getString(R.string.txtDesF3)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.nokidhungry.org/"));
                    }
                    else if(res_label.equals(getString(R.string.txtF4)) && des_label.equals(getString(R.string.txtDesF4)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.fh.org/"));
                    }
                    else if(res_label.equals(getString(R.string.txtF5)) && des_label.equals(getString(R.string.txtDesF5)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.foodforthepoor.org/"));
                    }
                    startActivity(itemIntent);
                }
            };

            btnLink.setOnClickListener(btnLinkListener);
        }
    }
}
