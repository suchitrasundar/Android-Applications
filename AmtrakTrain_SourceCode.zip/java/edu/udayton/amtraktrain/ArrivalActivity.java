package edu.udayton.amtraktrain;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ArrivalActivity extends AppCompatActivity {

    public SharedPreferences sharedPref;
    private static final String RESULT_PREFIX="Your arrival time is ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arrival);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        final TextView output = (TextView)findViewById(R.id.txtArrival);
        final ImageView img=(ImageView)findViewById(R.id.imgArrival);


        int boardingTimeHours = sharedPref.getInt(MainActivity.HOURS_KEY, MainActivity.INITIAL_BOARDING_HOURS);
        int boardingTimeMinutes = sharedPref.getInt(MainActivity.MINUTES_KEY, MainActivity.INITIAL_BOARDING_MINUTES);
        int lengthMinutes = sharedPref.getInt(MainActivity.LENGTH_MINUTES_KEY,MainActivity.INITIAL_LENGTH_MINUTES);

        String resultString = "";


        if(boardingTimeHours > MainActivity.INITIAL_BOARDING_HOURS && boardingTimeMinutes > MainActivity.INITIAL_BOARDING_MINUTES && lengthMinutes > MainActivity.INITIAL_LENGTH_MINUTES )
        {

            int totalMin = boardingTimeMinutes + lengthMinutes;
            int hoursTotalMin = totalMin/60;
            int minTotalMin = totalMin%60;

            int resultMinutes = minTotalMin;
            int resultHours = boardingTimeHours + hoursTotalMin;

            if(resultHours>=24)
            {
                resultHours = resultHours - 24;
            }


            if(resultHours>=0 && resultHours<=6)
            {
                resultString = " Red Eye Arrival\n\n"+RESULT_PREFIX + resultHours+" hours and "+resultMinutes+" minutes";
            }
            else
            {
                resultString = RESULT_PREFIX + resultHours +" hours and "+ resultMinutes+ " minutes";
            }

            output.setText(resultString);


            if(resultHours>=0 && resultHours<=6)
            {
                img.setImageResource(R.drawable.redeye);
            }
            else
            {
                img.setImageResource(R.drawable.amtrak_train_image);
            }



        }



    }
}
