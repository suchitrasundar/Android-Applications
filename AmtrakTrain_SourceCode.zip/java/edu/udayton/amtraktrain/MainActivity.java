package edu.udayton.amtraktrain;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int boardingTimeHours;
    private int boardingTimeMins;
    private int lengthMins;

    public static final String HOURS_KEY="key1", MINUTES_KEY="key2", LENGTH_MINUTES_KEY="key3";

    public static final int INITIAL_BOARDING_HOURS = 0;
    public static final int INITIAL_BOARDING_MINUTES = 0;
    public static final int INITIAL_LENGTH_MINUTES = 0;

    public SharedPreferences sharedPref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btnArrival = (Button) findViewById(R.id.btnArrival);
        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        showBoardingHours();
        showBoardingMinutes();
        showLengthMinutes();

        View.OnClickListener btnArrivalListener = new View.OnClickListener() {


            final EditText inputBoardingTimeHours = (EditText) findViewById(R.id.txtBoardingHours);
            final EditText inputBordingTimeMinutes = (EditText) findViewById(R.id.txtBoardingMinutes);
            final EditText inputLengthMinutes = (EditText) findViewById(R.id.txtLength);

            private boolean validateDurationHours(int inputValue){
                return (inputValue>0 && inputValue<=23);
            }


            private boolean validateDurationMinutes(int inputValue){
                return (inputValue>=0 && inputValue<=59);
            }


            private boolean validateLengthMinutes(int inputValue){
                return(inputValue>0 && inputValue<=1500);
            }

            @Override
            public void onClick(View v)
            {
                String durationHours = inputBoardingTimeHours.getText().toString();

                try{
                    boardingTimeHours = Integer.parseInt(durationHours);

                    if(validateDurationHours(boardingTimeHours)==false){
                        throw new Exception("Invalid Hours for Boarding time! Please enter values between 0 and 23");
                    }
                }
                catch(Exception e){
                    Toast toast = Toast.makeText(MainActivity.this,"Invalid Hours for Boarding time! Please enter values between 0 and 23",Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }


                String durationMinutes = inputBordingTimeMinutes.getText().toString();

                try{
                    boardingTimeMins = Integer.parseInt(durationMinutes);

                    if(validateDurationMinutes(boardingTimeMins)==false){
                        throw new Exception("Invalid Minutes for Boarding time! Please enter values between 0 and 59");
                    }
                }
                catch(Exception e){
                    Toast toast = Toast.makeText(MainActivity.this,"Invalid Minutes for Boarding time! Please enter values between 0 and 59",Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }



                String lengthInputMinutes = inputLengthMinutes.getText().toString();

                try{
                    lengthMins = Integer.parseInt(lengthInputMinutes);

                    if(validateLengthMinutes(lengthMins)==false){
                        throw new Exception("Invalid Minutes for Length! Please enter values 0 and 1500");
                    }
                }
                catch(Exception e){
                    Toast toast = Toast.makeText(MainActivity.this,"Invalid Minutes for Length! Please enter values between 0 and 1500",Toast.LENGTH_LONG);
                    toast.show();
                    return;
                }


                SharedPreferences.Editor editor= sharedPref.edit();
                editor.putInt(HOURS_KEY,boardingTimeHours);
                editor.putInt(MINUTES_KEY,boardingTimeMins);
                editor.putInt(LENGTH_MINUTES_KEY,lengthMins);
                editor.commit();


                Intent intent = new Intent(MainActivity.this,ArrivalActivity.class);
                startActivity(intent);
            }
        };

        btnArrival.setOnClickListener(btnArrivalListener);


    }

    private void showBoardingHours()
    {

        final EditText textBoardingTimeHours = (EditText)findViewById(R.id.txtBoardingHours);

        boardingTimeHours = sharedPref.getInt(HOURS_KEY,INITIAL_BOARDING_HOURS);

        if(boardingTimeHours > INITIAL_BOARDING_HOURS){
            textBoardingTimeHours.setText(Integer.toString(boardingTimeHours));
        }

    }


    private void showBoardingMinutes()
    {
        final EditText textBoardingTimeMinutes = (EditText)findViewById(R.id.txtBoardingMinutes);

        boardingTimeMins = sharedPref.getInt(MINUTES_KEY,INITIAL_BOARDING_MINUTES);

        if(boardingTimeMins > INITIAL_BOARDING_MINUTES){
            textBoardingTimeMinutes.setText(Integer.toString(boardingTimeMins));
        }

    }


    private void showLengthMinutes()
    {
        final EditText textLengthMinutes = (EditText)findViewById(R.id.txtLength);

        lengthMins = sharedPref.getInt(LENGTH_MINUTES_KEY,INITIAL_LENGTH_MINUTES);

        if(lengthMins > INITIAL_LENGTH_MINUTES){
            textLengthMinutes.setText(Integer.toString(lengthMins));
        }

    }


}





