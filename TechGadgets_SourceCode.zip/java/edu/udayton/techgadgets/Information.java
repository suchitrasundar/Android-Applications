package edu.udayton.techgadgets;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Information extends AppCompatActivity {

    public static final String ID_KEY = "RES_ID",
    LBL_KEY = "LABEL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);


        Intent myIntent = getIntent();

        Bundle myExtras = myIntent.getExtras();

        if(myExtras!=null)
        {
            final String res_label = myExtras.getString(LBL_KEY);

            final TextView titleTextView = (TextView) findViewById(R.id.titleTextView);
            titleTextView.setText(res_label);


            String image_id = myExtras.getString(ID_KEY);

            int imageId = Integer.parseInt(image_id);

            final ImageView pictureImageView = (ImageView) findViewById(R.id.pictureImageView);
            pictureImageView.setImageResource(imageId);
            pictureImageView.setContentDescription(res_label);

            Button btnLink = (Button) findViewById(R.id.btnLink);

            View.OnClickListener btnLinkListener = new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {

                    Intent itemIntent = null;


                    if (res_label.equals(getString(R.string.txtLight)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.amazon.com/Philips-Headspace-Subscription-HF3650-60/dp/B075S53HD9"));
                    }
                    else if (res_label.equals(getString(R.string.txtHub)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=x3vdytgru2E"));
                    }
                    else if (res_label.equals(getString(R.string.txtLock)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=BWjQEpOkb_0"));
                    }
                    else if (res_label.equals(getString(R.string.txtHeadset)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.oculus.com/go/?locale=en_US"));
                    }
                    else if (res_label.equals(getString(R.string.txtMouse)))
                    {
                        itemIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.anker.com/ca/products/variant/anker-wireless-mouse/A7853011"));
                    }
                    startActivity(itemIntent);

                }
            };

            btnLink.setOnClickListener(btnLinkListener);

        }
    }
}
