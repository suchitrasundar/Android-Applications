package edu.udayton.techgadgets;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;

public class Gadgets extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_gadgets);

        //ListView listView = (ListView) findViewById(R.id.);


        List<String> Gadget = Arrays.asList(getResources().getStringArray(R.array.GadgetList));
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_gadgets, R.id.gadget, Gadget));
    }

        protected void onListItemClick(ListView l, View v, int position, long id)
        {
            Intent itemIntent;

            switch (position)
            {
                case 0:
                    itemIntent = new Intent(Gadgets.this, Information.class);
                    itemIntent.putExtra(Information.LBL_KEY,
                            getResources().getString(R.string.txtLight));

                    itemIntent.putExtra(Information.ID_KEY,
                            Integer.toString(R.drawable.light));
                    break;

                case 1:
                    itemIntent = new Intent(Gadgets.this, Information.class);
                    itemIntent.putExtra(Information.LBL_KEY,
                            getResources().getString(R.string.txtHub));

                    itemIntent.putExtra(Information.ID_KEY,
                            Integer.toString(R.drawable.hub));
                    break;

                case 2:
                    itemIntent = new Intent(Gadgets.this, Information.class);
                    itemIntent.putExtra(Information.LBL_KEY,
                            getResources().getString(R.string.txtLock));

                    itemIntent.putExtra(Information.ID_KEY,
                            Integer.toString(R.drawable.lock));
                    break;

                case 3:
                    itemIntent = new Intent(Gadgets.this, Information.class);
                    itemIntent.putExtra(Information.LBL_KEY,
                            getResources().getString(R.string.txtHeadset));

                    itemIntent.putExtra(Information.ID_KEY,
                            Integer.toString(R.drawable.headset));
                    break;

                case 4:
                    itemIntent = new Intent(Gadgets.this, Information.class);
                    itemIntent.putExtra(Information.LBL_KEY,
                            getResources().getString(R.string.txtMouse));

                    itemIntent.putExtra(Information.ID_KEY,
                            Integer.toString(R.drawable.mouse));
                    break;

                default:
                    Toast myToast = Toast.makeText(Gadgets.this,
                            "Invalid Choice Made", Toast.LENGTH_LONG);

                    myToast.show();
                    itemIntent = null;
                    break;
            }

            if(itemIntent !=null)
            {
                startActivity(itemIntent);
            }

        }

    }

